<?php

namespace FourLabs\GampBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FourLabsGampBundle extends Bundle
{
}
