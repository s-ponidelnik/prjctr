<?php

namespace TheIconic\Tracking\GoogleAnalytics\Tests;

use TheIconic\Tracking\GoogleAnalytics\Parameters\CompoundParameterCollection;

class CompoundParameterTestCollection extends CompoundParameterCollection
{
    protected $name = 'cp:i:t';
}
