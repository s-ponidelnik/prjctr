<?php
include_once __DIR__ . '/../classes/SingleTestParameter.php';
include_once __DIR__ . '/../classes/CompoundTestParameter.php';
include_once __DIR__ . '/../classes/CompoundParameterTestCollection.php';
include_once __DIR__ . '/../classes/InvalidCompoundParameterTestCollection.php';
include_once __DIR__ . '/../classes/SingleTestParameterIndexed.php';
include_once __DIR__ . '/../classes/InvalidSingleTestParameter.php';
include_once __DIR__ . '/../../../vendor/autoload.php';
