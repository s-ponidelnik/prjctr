<?php

namespace TheIconic\Tracking\GoogleAnalytics\Tests;

use TheIconic\Tracking\GoogleAnalytics\Parameters\SingleParameter;

class SingleTestParameterIndexed extends SingleParameter
{
    protected $name = 'testi:i:';
}
