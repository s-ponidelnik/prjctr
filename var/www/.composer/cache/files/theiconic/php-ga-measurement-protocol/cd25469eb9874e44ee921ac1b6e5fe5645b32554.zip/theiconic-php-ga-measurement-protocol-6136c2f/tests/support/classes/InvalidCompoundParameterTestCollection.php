<?php

namespace TheIconic\Tracking\GoogleAnalytics\Tests;

use TheIconic\Tracking\GoogleAnalytics\Parameters\CompoundParameterCollection;

class InvalidCompoundParameterTestCollection extends CompoundParameterCollection
{
}
